define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.originalEvent
     */
    async run(context, { event, originalEvent }) {
      const { $page, $flow, $application, $constants, $variables } = context;
      if ($variables.Entity_Variable.email === '' || $variables.Entity_Variable.email == null || $variables.Entity_Variable.feedback === '' || $variables.Entity_Variable.feedback == null || $variables.Entity_Variable.name === '' || $variables.Entity_Variable.name == null) {

        // CheckNullorEmpty
          await Actions.fireNotificationEvent(context, {
            summary: 'Missing Input',
            message: "Please enter your inputs properly",
          }, { id: 'ErrorMessage' });
      } else {
        // this will take input of valid inputs
        const response = await Actions.callRest(context, {
          endpoint: 'feedback/postIcApiIntegrationV1FlowsRestFEEDBACK_FORM_INT1_0Get_Inputs_from_vbcs',
          body: $variables.Entity_Variable,
        }, { id: 'SuccessInputRest' });

        await Actions.fireNotificationEvent(context, {
          summary: 'Congratulations!!',
          message: 'Your feedback is submitted',
          displayMode: 'transient',
          type: 'confirmation',
        }, { id: 'InputsSubmitted' });

        // ReassignNull
        $variables.Entity_Variable.email = '';
        $variables.Entity_Variable.feedback = '';
        $variables.Entity_Variable.name = '';
      }
    }
  }

  return ButtonActionChain;
});
